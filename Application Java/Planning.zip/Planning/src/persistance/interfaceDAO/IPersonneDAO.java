package persistance.interfaceDAO;

//import java.util.List;
//import metier.Personne;

public interface IPersonneDAO {
    
    //public List<Personne> getPersonnes();
    
}
