package persistance.interfaceDAO;

import java.util.List;
import metier.Jury;

public interface IJuryDAO {
    
    public List<Jury> getJurys();
    
}
