<?php require_once(PATH_VIEWS . 'header.php'); ?>
<?php require_once(PATH_VIEWS . 'alert.php'); ?>
<?php require_once(PATH_VIEWS . 'footer.php'); ?>
