					<!-- fin de page -->
			</section>
	</body>
	<!-- Pied de page -->
	<footer class="modal-footer">
		<?=AUTEUR?>
	</footer>
</html>	
