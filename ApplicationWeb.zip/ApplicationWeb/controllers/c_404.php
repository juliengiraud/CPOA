<?php

$alert = choixAlert('url_non_valide');

// Appel de la vue
require_once(PATH_VIEWS.$page.'.php'); 

?>
